#include <linux/module.h>
#include <linux/init.h>
#include <linux/types.h>
#include <linux/kernel.h>
#include <net/tcp.h>

static u32 llm_cc_10_14_ssthresh(struct sock *sk)
{
    const struct tcp_sock *tp = tcp_sk(sk);
    return max_t(u32, (tp->snd_cwnd * 8U) / 10U, 2U * tp->mss_cache);
}

static void llm_cc_10_14_cong_avoid(struct sock *sk, u32 ack, u32 acked)
{
    struct tcp_sock *tp = tcp_sk(sk);
    u32 srtt_ms;
    if (!tcp_is_cwnd_limited(sk))
        return;
    if (tcp_in_slow_start(tp)) {
        tcp_slow_start(tp, acked);
    } else {
        srtt_ms = (tp->srtt_us >> 3) / 1000;
        if (srtt_ms > 90) {
            if (tp->snd_cwnd_cnt >= tp->snd_cwnd * 2) {
                tp->snd_cwnd++;
                tp->snd_cwnd_cnt = 0;
            } else {
                tp->snd_cwnd_cnt += acked;
            }
        } else {
            tcp_cong_avoid_ai(tp, tp->snd_cwnd, acked);
        }
    }
}

static u32 llm_cc_10_14_undo_cwnd(struct sock *sk)
{
    const struct tcp_sock *tp = tcp_sk(sk);
    return tp->snd_cwnd;
}

static struct tcp_congestion_ops llm_cc_10_14 __read_mostly = {
    .name       = "llm_cc_10_14",
    .owner      = THIS_MODULE,
    .ssthresh   = llm_cc_10_14_ssthresh,
    .cong_avoid = llm_cc_10_14_cong_avoid,
    .undo_cwnd  = llm_cc_10_14_undo_cwnd,
};

static int __init llm_cc_10_14_register(void)
{
    return tcp_register_congestion_control(&llm_cc_10_14);
}

static void __exit llm_cc_10_14_unregister(void)
{
    tcp_unregister_congestion_control(&llm_cc_10_14);
}

module_init(llm_cc_10_14_register);
module_exit(llm_cc_10_14_unregister);

MODULE_AUTHOR("FlexNGIA Agent");
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("LLM Generated CC");