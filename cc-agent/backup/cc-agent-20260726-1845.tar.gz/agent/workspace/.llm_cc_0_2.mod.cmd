savedcmd_llm_cc_0_2.mod := printf '%s\n'   llm_cc_0_2.o | awk '!x[$$0]++ { print("./"$$0) }' > llm_cc_0_2.mod
