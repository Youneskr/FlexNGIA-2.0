savedcmd_modules.order := {   echo llm_cc_0_2.o; :; } > modules.order
