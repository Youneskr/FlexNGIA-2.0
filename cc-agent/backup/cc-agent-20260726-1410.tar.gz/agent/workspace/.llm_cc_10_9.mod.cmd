savedcmd_llm_cc_10_9.mod := printf '%s\n'   llm_cc_10_9.o | awk '!x[$$0]++ { print("./"$$0) }' > llm_cc_10_9.mod
